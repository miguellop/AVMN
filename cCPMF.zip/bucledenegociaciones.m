%%
experimenttypestr = 'random';
negoDSNPc
