function z = mycircle(x, y, center, radio)
    z = (x-center(1)).^2+(y-center(2)).^2-radio.^2;
end